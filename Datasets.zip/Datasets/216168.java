package ical;
import java.util.*;

public class Main {
    public static Hashtable sumr = new Hashtable();
    public static Hashtable monthYear = new Hashtable();
    public String contents;
    private static int [] descST = new int [10000];
    private static int [] sumStart = new int [10000];
    private static int [] sumEnd = new int [10000];
    private static int [] dtSt = new int [10000];
    private static int [] dtEn = new int [10000];
    private static int [] deSt = new int [10000];
    private static int [] deEn = new int [10000];
    private static String [] descrip = new String[10000];
    private static String [] summary = new String [10000];
    private static String [] dtStart = new String [10000];
    private static String [] dtEnd = new String [10000];
    private static String [] yearStarts = new String [10000];
    private static String [] monthStarts = new String [10000];
    private static String [] dayStarts = new String [10000];
    private static String [] timeStarts = new String [10000];
    private static String [] yearEnds = new String [10000];
    private static String [] monthEnds = new String [10000];
    private static String [] dayEnds = new String [10000];
    private static String [] timeEnds = new String [10000];
    private static Calendar calendar = Calendar.getInstance();
    private static String [][] entry = new String [10000][10000];
    private static int ct = 0;
    private static String [] years = new String [10000];
    private static String [] months = new String [10000];
    private static String [] yr = new String [10000];
    private static String [] mnt = new String [10000];
    private static int f = 1; 
    
  public static void main(String[] args) {
    try {
      String contents = ICalendarToString.getCalendarAsString(args[0]);
      int length = countOccuren(contents, "SUMMARY:");
      int lengthDesc = countOccuren(contents, "DESCRIPTION:");
      //System.out.println(lengthDesc);
      sumStart = new int [length];
      sumEnd = new int [length];
      descST = new int [lengthDesc];
      
      entry = new String [length][length];
      summary = new String [length];
      sumStart = getIndex(contents, "SUMMARY:");
      sumEnd = getIndex(contents, "CREATED:");
      descST = getIndex(contents, "DESCRIPTION:");
      dtSt = getIndex(contents, "DTSTART;TZID=US/Pacific:");
      dtEn = getIndex(contents, "DTSTAMP:");
      deSt = getIndex(contents, "DTEND;TZID=US/Pacific:");
      deEn = getIndex(contents, "END:VEVENT");
      descrip = new String [lengthDesc];
      dtStart = new String [length];
      dtEnd = new String [length];
      yearStarts = new String [length];
      monthStarts = new String [length];
      dayStarts = new String [length];
      timeStarts = new String [length];
      yearEnds = new String [length];
      monthEnds = new String [length];
      dayEnds = new String [length];
      timeEnds = new String [length];
      for (int n = 0; n<descST.length; n++){
         if(descST[n] == -1) {
              break;
         }
         
          descrip[n] = contents.substring(descST[n] + 12, descST[n] + 200);
          //descrip[n].substring(1, getIndex(descrip[n],"\n"));
          //System.out.println("Description:"+descrip[n].substring(0,descrip[n].indexOf("\n")));
          String dessc = descrip[n].substring(0,descrip[n].indexOf("\n"));
         
          int indx = descrip[n].indexOf("DTSTART;TZID=US/Pacific:", 0);
          //System.out.println(indx);
         //Parse date and time of an events which has a DESCRIPTION field 
          String ddate = descrip[n].substring(indx+24,indx+ 39);
         //Remove T from date e.g 20080619T160000 becomes 20080619160000
          ddate = ddate.replace("T", "");
         //Associate date and description field using hashtable. Key is date, value is description
          sumr.put(ddate,dessc);
          System.out.println(sumr.get("20080703080000"));
          
      }
      for (int i = 0; i<sumStart.length; i++){
          if(sumStart[i] == -1) {
         break;
         }
      //Parsing substrings 
      //summary[i] = contents.substring(sumStart[i] + 8, sumEnd[i] - 1 );
          summary[i] = contents.substring(sumStart[i] + 8, sumStart[i] + 50 );
      //added july 7th
      summary[i] = summary[i].substring(0, summary[i].indexOf("\n"));
     // dtStart[i] = contents.substring(dtSt[i] + 24, dtEn[i] - 1);
      dtStart[i] = contents.substring(dtSt[i] + 24, dtSt[i] + 50);
      //added july 7th
      dtStart[i] = dtStart[i].substring(0, dtStart[i].indexOf("\n"));
      //dtEnd[i] = contents.substring(deSt[i] + 22, deEn[i] - 1);
      dtEnd[i] = contents.substring(deSt[i] + 22, deSt[i] + 50);
      //added july 7th
      dtEnd[i] = dtEnd[i].substring(0, dtEnd[i].indexOf("\n"));
      yearStarts[i] = dtStart[i].substring(0, 4);
      monthStarts[i] = dtStart[i].substring(4, 6);
      dayStarts[i] = dtStart[i].substring(6, 8);
      timeStarts[i] = dtStart[i].substring(9, 15);
      yearEnds [i] = dtEnd[i].substring(0, 4); 
      monthEnds [i] = dtEnd[i].substring(4, 6);
      dayEnds [i] = dtEnd[i].substring(6, 8);
      timeEnds [i] = dtEnd[i].substring(9, 15); 
      dtStart[i] = dtStart[i].replace("T", "");
      entry[i][0] = summary[i] + yearEnds[i] + monthEnds[i] + dayEnds[i] + timeEnds[i]   ;
      entry[i][1] = dtStart[i];
      
      
      monthYear.put(i, yearStarts[i]+monthStarts[i]);
//      System.out.println(monthYear.get(i));      

      }
      
      Arrays.sort(dtStart);
      //Sort 2D array 
      java.util.Arrays.sort(entry, new java.util.Comparator<String[]>() {
      public int compare(String[] o1, String[] o2) {
        if(Double.parseDouble(o1[1]) > Double.parseDouble(o2[1])) {
          return 1;
        } else if(Double.parseDouble(o1[1]) < Double.parseDouble(o2[1])) {
          return -1;
        } else {
          return 0;
        }
      }
 
    }
    );
    for(int i = 0; i < entry.length; i++) {
        //this is sorted by date it starts (summary and other corrensponding parameters )
        summary[i] = entry[i][0].substring(0, entry[i][0].length()-14);
        yearEnds[i] = entry[i][0].substring(entry[i][0].length()-14, entry[i][0].length()-10);
        monthEnds[i] = entry[i][0].substring(entry[i][0].length()-10, entry[i][0].length()-8);
        dayEnds[i] = entry[i][0].substring(entry[i][0].length()-8, entry[i][0].length()-6);
        timeEnds[i] = entry[i][0].substring(entry[i][0].length()-6, entry[i][0].length());
        
        yearStarts[i] = entry[i][1].substring(0, 4);
        monthStarts [i] = entry[i][1].substring(4, 6);
        dayStarts [i] = entry[i][1].substring(6, 8);
        timeStarts [i] = entry[i][1].substring(8, 14);
       // System.out.println("Summary: "+ summary[i] + " Year starts: " + yearStarts[i]+ " Month Starts: " + monthStarts [i] + " Day starts " + dayStarts [i] + " Time starts: " + timeStarts [i]);
       
    }
    years[0] =  yearStarts[0];
    months[0] = monthStarts[0];
    
    
    for (int k=1; k<yearStarts.length; k++){
         //System.out.println(yearStarts[k] + years[f-1] + "*");
         if (yearStarts[k].equalsIgnoreCase(years[f-1])&&monthStarts[k].equalsIgnoreCase(months[f-1])){
             continue;         
         }
        
         years[f] =  yearStarts[k];
         months[f] = monthStarts[k];
     
         f++;
    
    }
   //yr and mnt arrays contains months and corresponding year which will be used to create unique php file(s)
    yr = new String [f];
    mnt = new String[f];
     for (int g=0; g<yr.length; g++){
         yr[g]=years[g];
         mnt[g]=months[g];
   //System.out.println(yr[g] + " " + mnt[g]);
         doIt(yr[g],mnt[g]);
         System.out.println("Php file(s) created!");
     }
    
      
    } catch (CalendarNotFoundException e) {
      System.out.println("Could not find Calendar .ics: " + e.getMessage());
    }catch ( OutOfMemoryError e )
{
   System.out.println("Out of memory");
}
    System.out.println("PHP file(s) created successfully!");

  }
  public static boolean monthExists(String s){
     boolean reslt = false;
      for (int y=0; y<years.length; y++){
          
       if (years[y].equalsIgnoreCase(s)){
           reslt = true; 
       }else {
          reslt = false;
        }
     }
     return reslt;
  }
  public static void doIt(String yearS, String monthS){
      String monthBefore = Integer.toString(Integer.parseInt(monthS)-1);
      String monthAfter = Integer.toString(Integer.parseInt(monthS)+1);
      if (monthBefore.matches("0")){
          monthBefore = "12";
      }else if (monthBefore.length()==1){
        monthBefore = "0" + monthBefore;
      }
      if(monthAfter.matches("13")){
        monthAfter = "01";
      }else if (monthAfter.length()==1){
        monthAfter = "0" + monthAfter;
      }
       String site = "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\"\n\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\">\n<html xmlns=\"http://www.w3.org/1999/xhtml\" id=\"sixapart-standard\">\n<head>\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\n<link rel=\"stylesheet\" href=\"http://bl1231.als.lbl.gov/sibyls-styles.css\" type=\"text/css\" />\n<title>\nSIBYLS Beamline Schedule :: " + getMonth(Integer.parseInt(monthS))+ " " + yearS +"</title>\n</head>\n<body body id=\"sectionthree\" class=\"mt-main-index layout-wide\">\n<div id=\"container\">\n<div id=\"container-inner\">\n<div id=\"header\">\n<div id=\"header-inner\">\n<div id=\"header-content\">\n<?php include \"/www/html/sibyls/includes/cal_banner.inc\"; ?>\n</div>\n</div>\n</div>\n<div id=\"content\">\n<div id=\"content-inner\">\n<?php include \"/www/html/sibyls/includes/menubar.inc\"; ?>\n<div id=\"alpha\">\n<div id=\"alpha-inner\">\n<div class=\"page-asset asset\">\n<div class=\"asset-header\">\n<h1 class=\"asset-name\"></h1>\n</div><div class=\"asset-content\">\n<div class=\"asset-body\">\n<h3 style=\"text-align: center\"><-- ";
           if(monthS.equalsIgnoreCase("01")){
               if(monthYear.containsValue(Integer.toString(Integer.parseInt(yearS)-1)+monthBefore)){
                site = site+"<a href=\"" +"/schedule/"+ Integer.toString(Integer.parseInt(yearS)-1)+"/"+ getMonth(Integer.parseInt(monthS)-1)+(Integer.parseInt(yearS)-1) + ".php\">"+ getMonth(Integer.parseInt(monthS)-1)+ " "+(Integer.parseInt(yearS)-1);
               } else {
                   
               }
    } else{
        if(monthYear.containsValue(Integer.toString(Integer.parseInt(yearS))+ monthBefore)){
            //System.out.println(yearS+ monthS +"HAS A previous month###################"+ Integer.toString(Integer.parseInt(yearS))+ Integer.toString(Integer.parseInt(monthS)-1));
           site = site +"<a href=\"" +getMonth(Integer.parseInt(monthS)-1)+(Integer.parseInt(yearS)) + ".php\">"+ getMonth(Integer.parseInt(monthS)-1)+ " "+(Integer.parseInt(yearS));
        } else {
           // System.out.println(yearS+ monthS +"Doesn't have a month before it" + Integer.toString(Integer.parseInt(yearS))+ Integer.toString(Integer.parseInt(monthS)-1));
        }
     } 
      site = site + " </a>--- <a href=\"http://bl1231.als.lbl.gov/schedule/schedule.php\">index</a> --- ";
      if(monthS.equalsIgnoreCase("12")){
   if(monthYear.containsValue(Integer.toString(Integer.parseInt(yearS)+1)+ monthAfter)){
        site = site+"<a href=\"" +"/schedule/"+ Integer.toString(Integer.parseInt(yearS)+1)+"/"+getMonth(Integer.parseInt(monthS) + 1)+(Integer.parseInt(yearS)+1) + ".php\">" + getMonth(Integer.parseInt(monthS) + 1)+ " " +(Integer.parseInt(yearS)+1);
   }else{}
   
    } else{
   if(monthYear.containsValue(Integer.toString(Integer.parseInt(yearS))+ monthAfter)){
           site = site+"<a href=\"" +getMonth(Integer.parseInt(monthS) + 1)+(Integer.parseInt(yearS)) + ".php\">" + getMonth(Integer.parseInt(monthS) + 1)+ " " +(Integer.parseInt(yearS));
   }else{}
    }
      
              
       
       site = site + " </a>--> </h3>\n<h2 class=\"cbox\">" + getMonth(Integer.parseInt(monthS)) + " "+ yearS + "  -- Beamline 12.3.1 Schedule</h2>\n<table class=\"cal\">";
    site = site + "\n<tr>\n<td width=\"31\"><font face=\"Arial, Helvetica, sans-serif\">.</font></td>\n<td width=\"31\"><font face=\"Arial, Helvetica, sans-serif\">.</font></td>\n<td width=\"210\"><font face=\"Arial, Helvetica, sans-serif\">1:00am-9:00am</font></td>\n<td width=\"210\"><font face=\"Arial, Helvetica, sans-serif\">9:00am-5:00pm</font></td>\n<td width=\"210\"><font face=\"Arial, Helvetica, sans-serif\">5:00pm-1:00am</font></td>\n</tr>";
    String bottom =  "</table>\n<h3 style=\"text-align: center\"><-- ";
    
               if(monthS.equalsIgnoreCase("01")){
               if(monthYear.containsValue(Integer.toString(Integer.parseInt(yearS)-1)+monthBefore)){
                bottom = bottom+"<a href=\"" +"/schedule/"+ Integer.toString(Integer.parseInt(yearS)-1)+"/"+ getMonth(Integer.parseInt(monthS)-1)+(Integer.parseInt(yearS)-1) + ".php\">"+ getMonth(Integer.parseInt(monthS)-1)+ " "+(Integer.parseInt(yearS)-1);
               } else {
                   
               }
    } else{
        if(monthYear.containsValue(Integer.toString(Integer.parseInt(yearS))+ monthBefore)){
           
           bottom = bottom +"<a href=\"" +getMonth(Integer.parseInt(monthS)-1)+(Integer.parseInt(yearS)) + ".php\">"+ getMonth(Integer.parseInt(monthS)-1)+ " "+(Integer.parseInt(yearS));
        } else {
           
        }
     } 
    
    bottom = bottom + " </a>--- <a href=\"http://bl1231.als.lbl.gov/schedule/schedule.php\">index</a> --- <a href=\""; 
    if(monthS.equalsIgnoreCase("12")){
     if(monthYear.containsValue(Integer.toString(Integer.parseInt(yearS)+1)+ monthAfter)){
        bottom = bottom +"/schedule/"+ Integer.toString(Integer.parseInt(yearS)+1)+"/"+getMonth(Integer.parseInt(monthS) + 1)+(Integer.parseInt(yearS)+1) + ".php\">" + getMonth(Integer.parseInt(monthS) + 1)+ " " +(Integer.parseInt(yearS)+1);
     }else {}
     } else{
        if(monthYear.containsValue(Integer.toString(Integer.parseInt(yearS))+ monthAfter)){
        bottom = bottom +getMonth(Integer.parseInt(monthS) + 1)+(Integer.parseInt(yearS)) + ".php\">" + getMonth(Integer.parseInt(monthS) + 1)+ " " +(Integer.parseInt(yearS));
        }else {}
    }
    bottom = bottom + "</a> --> </h3>\n</div>\n</div>\n<div class=\"asset-footer\">\n</div>\n</div>\n</div>\n</div>\n</div>\n</div>\n<?php include \"/www/html/sibyls/includes/cal_footer.inc\"; ?>\n</div>\n</div>\n</div>\n</body>\n</html>";

   for (int i = 0; i < getDaysInMonth(Integer.parseInt(yearS),Integer.parseInt(monthS)); i++){
     
        site = site + "\n<tr>\n<td width=\"31\">"+(i+1) +"</td>\n<td width=\"31\">"+getDay(Integer.parseInt(yearS),Integer.parseInt(monthS), (i+1))+"</td>\n<td width=\"210\""+ getDescColor(yearS+monthS+Integer.toString(i+1)+"000000") +">";
       
        site = site + getFirstShift(i, yearS, monthS );
        site = site + "</td>\n<td width=\"210\""+ getDescColor(yearS+monthS+Integer.toString(i+1)+"080000") +">";
        site = site + getSecondShift(i, yearS, monthS );
        site = site + "</td>\n<td width=\"210\""+getDescColor(yearS+monthS+Integer.toString(i+1)+"160000") +">";
        site = site + getThirdShift(i, yearS, monthS );
        site = site + "</td>\n</tr>\n";
              
    }
    site = site + bottom;
    try{ 
    ICalendarFromString.saveStringAsCalendarFile(site, getMonth(Integer.parseInt(monthS)) + yearS  );
    } catch (CalendarNotSavedException e) {
      System.out.println("Could not save transformed calendar: " + e.getMessage());
    }
    
  }
  
   
  //Returns first shift of a day (000000 to 080000 iin ical / 1am to 9am in web calendar)
  public static String getFirstShift(int z, String ys, String ms){
  String field = ".";
  
  
  for(int k=0;k<summary.length; k++){
     if(Integer.parseInt(yearStarts[k])==Integer.parseInt(ys) && Integer.parseInt(monthStarts[k])==Integer.parseInt(ms) && Integer.parseInt(dayStarts[k])==(z+1) && Integer.parseInt(timeStarts[k])== (0)){
        field = summary[k];
     }
  }
   //Instead of User Operation display "."
  if (field.contains("User Operation")){
        field = ".";
  }
  return field;
  
  } 
  //Returns second shift of a day 
  public static String getSecondShift(int z, String ys, String ms){
  String field = ".";
  
  
  for(int k=0;k<summary.length; k++){
     if(Integer.parseInt(yearStarts[k])==Integer.parseInt(ys) && Integer.parseInt(monthStarts[k])==Integer.parseInt(ms) && Integer.parseInt(dayStarts[k])==(z+1) && Integer.parseInt(timeStarts[k])== (80000)){
        field = summary[k];
     }
  }
   //Instead of User Operation display "."
  if (field.contains("User Operation")){
        field = ".";
  }
  return field;
  
  } 
  public static String getThirdShift(int z,  String ys, String ms){
  String field = ".";
  
  
  for(int k=0;k<summary.length; k++){
     if(Integer.parseInt(yearStarts[k])==Integer.parseInt(ys) && Integer.parseInt(monthStarts[k])==Integer.parseInt(ms) && Integer.parseInt(dayStarts[k])==(z+1) && Integer.parseInt(timeStarts[k])== (160000)){
        field = summary[k];
     }
  }
  //Instead of User Operation display "."
  if (field.contains("User Operation")){
        field = ".";
  }
  return field;
  
  } 
  public static int countOccuren(String s, String sub)
{
    int count = 0;
    int index = s.indexOf(sub, 0);
    while(index != -1)
    {
        count++;
        if( index < s.length()-1 ){
            index = s.indexOf(sub, index+1);
          
        } else
            index = -1;
    }
    return count;
}
public static int [] getIndex(String s, String sub)
{
    ct = 0;
    int [] ar = new int [10000];
    int count = 0;
    int index = s.indexOf(sub, 0);
    while(index != -1)
    {
        count++;
        if( index < s.length()-1 ){
            index = s.indexOf(sub, index);

            ar[ct] = index;
            
            ct++;
           
           if (index == -1 ){break;}
            index = index +1;
          
        } else
            index = -1;
    }
    return ar;
}

//Given year,month,day return what day of the week it is
//in CALENDAR months are 0 to 11
public static String getDay(int year, int month, int day){
       String dayWeek = null;
       calendar.set(year, month - 1, day);
       int dayofWeek = calendar.get(Calendar.DAY_OF_WEEK);
       
       switch (dayofWeek) {
            case 1:  dayWeek = "Su"; break;
            case 2:  dayWeek = "M"; break;
            case 3:  dayWeek = "Tu"; break;
            case 4:  dayWeek = "W"; break;
            case 5:  dayWeek = "Th"; break;
            case 6:  dayWeek = "F"; break;
            case 7:  dayWeek = "Sa"; break;
            default: System.out.println("Invalid day.");break;
        }
       calendar.clear();

return dayWeek;
}
//Given year and month return number of days in that month (e.g for 2008 February function will return 29, for 2007 February it returns 28 )
public static int getDaysInMonth(int year, int month) {
 int day = 1;
 int daysinMonth = 0;
calendar.set(year, month - 1, day);
daysinMonth = calendar.getActualMaximum(Calendar.DAY_OF_MONTH);


return daysinMonth;
   
}
//with case 0 and case 13 I am able to use the same altorithm for all months, no special cases like (January and December) 
public static String getMonth(int month){
String mnth = null;
int mon = month;

switch (mon) {
            case 0:  mnth = "December"; break;
            case 1:  mnth = "January"; break;
            case 2:  mnth = "February"; break;
            case 3:  mnth = "March"; break;
            case 4:  mnth = "April"; break;
            case 5:  mnth = "May"; break;
            case 6:  mnth = "June"; break;
            case 7:  mnth = "July"; break;
            case 8:  mnth = "August"; break;
            case 9:  mnth = "September"; break;
            case 10:  mnth = "October"; break;
            case 11:  mnth = "November"; break;
            case 12:  mnth = "December"; break;
            case 13:  mnth = "January"; break; 
            default: System.out.println("Invalid month.");break;
        }
return mnth;


}
//Make this function take date of description method and returns a color that corresponds to the description (HASHTABLE)
public static String getDescColor(String yearmonth){
    //System.out.println("yearmonth " + yearmonth );
    if (yearmonth.length()== 13){
        yearmonth = yearmonth.substring(0, 6) + "0" + yearmonth.substring(6, 13);
    }
     System.out.println("yearmonth " + yearmonth );
     String description = (String)sumr.get(yearmonth);
     String color = " class=\"off\"";
     if(description==null){
       return color;
     }else if (description.contains("NO")){
        color = " class=\"unavailable\"";
     } else if (description.contains("STARTUP")){
       color = " class=\"startup\"";
     }else if (description.contains("SBDR")) {
       color = " class=\"sbdr\"";
     }else if (description.contains("GU")) {
       color = " class=\"gu\"";
     }else if (description.contains("MAGGIE")) {
       color = " class=\"maggie\"";
     }else if (description.contains("IDAT")) {
       color = " class=\"idat\"";
     }else if (description.contains("YES")) {
       color = " class=\"available\"";
     }
     yearmonth = null;
     return color;

}


}
