//******************************************************************************
// FileDate.java:	Applet
//
//******************************************************************************
import java.applet.*;
import java.awt.*;
import java.io.*;
import java.net.*;
import java.util.*;

//==============================================================================
// Main Class for applet FileDate
//
//==============================================================================

/** Displays parent html-file storing date/time.
* @author Andreas Will (eMail: a.will@t-online.de)
* @version 1.0 (22-feb-1997)
*/
public class FileDate extends Applet
{
	private final String PARAM_Image    = "BkGnd";      // parameter
  private final String PARAM_Text     = "Text";       // text preceding date/time
  private final String PARAM_File     = "File";       // file whose date/time is displayed
  private final String PARAM_Font     = "Font";       // output font
  private final String PARAM_FontSize = "FontSize";   // output fontsize
  private final String PARAM_FontColor= "FontColor";  // output fontcolor
  private final String PARAM_OffsetX  = "ImgOffsetX";
  private final String PARAM_OffsetY  = "ImgOffsetY";

  private String m_strLastModif = "last modified:";
  private String m_strFile      = null; // default is parent html doc
  private String m_strBkGnd     = "";   // Background image
  private Image  m_imgBkGnd     = null;
  private Point  m_ptOffset     = null;

	private String m_strErrorMsg = "";

	// FileDate Class Constructor
	//--------------------------------------------------------------------------
	public FileDate()
	{
		// TODO: Add constructor code here
	}

	// APPLET INFO SUPPORT:
	//		The getAppletInfo() method returns a string describing the applet's
	// author, copyright date, or miscellaneous information.
    //--------------------------------------------------------------------------
	public String getAppletInfo()
	{
		return "Name: FileDate\r\n" +
		       "Author: A.Will\r\n" +
		       "displays 'last modified'-string for parent html file\r\n" +
		       "Created with Microsoft Visual J++ Version 1.0";
	}

	// PARAMETER SUPPORT
	//		The getParameterInfo() method returns an array of strings describing
	// the parameters understood by this applet.
	//
    // FileDate Parameter Information:
    //  { "Name", "Type", "Description" },
    //--------------------------------------------------------------------------
	public String[][] getParameterInfo()
	{
		String[][] info =
		{
			{ PARAM_Image,   "String", "background image/color" },
      { PARAM_Text,    "String", "e.g.: last modified: [TT].[MM].[YYYY]"},
      { PARAM_File,    "String", "file to check"},
      { PARAM_Font,    "String", "[fontname; size; type; color] delimited by (;)"},
      { PARAM_OffsetX,   "int", "image offset X" },
			{ PARAM_OffsetY,   "int", "image offset Y" },
		};
		return info;		
	}

	// The init() method is called by the AWT when an applet is first loaded or
	// reloaded.  Override this method to perform whatever initialization your
	// applet needs, such as initializing data structures, loading images or
	// fonts, creating frame windows, setting the layout manager, or adding UI
	// components.
    //--------------------------------------------------------------------------
	public void init()
	{
		// PARAMETER SUPPORT
		//		The following code retrieves the value of each parameter
		// specified with the <PARAM> tag and stores it in a member
		// variable.
		//----------------------------------------------------------------------
		String param;
    int x,y;

    x=y=0;
   
		param = getParameter(PARAM_Image);
		if (param != null)
			m_strBkGnd = param;

		param = getParameter(PARAM_Text);
		if(param != null)
			m_strLastModif = param;

		param = getParameter(PARAM_File);
		if(param != null)
			m_strFile = param;

		param = getParameter(PARAM_Font);
		if(param != null)
			parseFontParam(param);

		param = getParameter(PARAM_OffsetX);
		if(param != null)
			x = Integer.parseInt(param);

		param = getParameter(PARAM_OffsetY);
		if(param != null)
			y = Integer.parseInt(param);

    m_ptOffset = new Point(x,y);
    // offset for image painting
    // to align image with background

    m_strLastModif+= " ";

    long lTime = getLastModified();

    if(lTime != 0)
    {
      formatDateTimeString(lTime);
    }
    else
      m_strLastModif = "- unknown -"; // unknown modification date

    resizeApplet();
  }

  private void resizeApplet()
  {
    FontMetrics m = getFontMetrics(getFont());
		int     width = m.stringWidth(m_strLastModif);
    int     height= m.getHeight();
		
    if(width <= 0)
			width = 1;

		resize(width, height);
	}

/**
* determines time the file was last modified
* @return___long__time value or 0L if an error occurs
*/
  private long getLastModified()
  {
    URL url;
    URLConnection urlC;
    File file;
    long lTime = 0;

    try
    {
      URL urlDoc;

      urlDoc = getDocumentBase();

      if(m_strFile != null)
        url = new URL(urlDoc, m_strFile);
      else
        url = urlDoc;

      file = new File(url.getFile());
    }
    catch(MalformedURLException e)
    {
      m_strErrorMsg+= "MalformedURLEx: doc:" + 
													getDocumentBase().toString() + 
													", file:" + m_strFile + "\r\n";
			return 0L;
    }

    try
    {
      lTime = file.lastModified();
    }
    catch(SecurityException e)
    {
      m_strErrorMsg+= "SecurityEx: no read access to file: " + file.toString() + "\r\n";
      lTime = 0;
    }

    if(lTime == 0)
    {// no read access to document file
      try
      {
        urlC  = url.openConnection();
        lTime = urlC.getLastModified(); // 0 if unknown
      }
      catch(IOException e)
      {
        m_strErrorMsg+= "IOEx: no access to url: " + url.toString() + "\r\n";
        lTime = 0;
      }
    }

    return lTime;
  }

/**
* Date/time formatting.
* If m_strLastModif contains formatting substrings:
* [D][DD]; [M][MM]; [N][NN]; [Y][YY]; [h][hh]; [m][mm]; [s][ss]
* these substring are replaced by respective date/time values
* If 2 letter format is used the respective value is preceded by leading zeros.
* The lowercase month format will return the monthname in abbreviated or normal form.
* Each format string may be used repeatedly.
*/
  private void formatDateTimeString(long lTime)
  {
    Date date;    
    boolean bFormat = false;
    String str;
    int nValues[];
    String strMonth[][]= {{"jan","feb","mar","apr","may","jun","jul","aug","sep","oct","nov","dec"},
                          {"january","february","march","april","may","june","july","august","september","october","november","december"}};
    String strMap[][] = 
    {{"[D]","[DD]","[M]","[MM]","[YY]","[Y]","[h]","[hh]","[m]","[mm]","[s]","[ss]","[N]","[NN]"},
     {"",   "",    "",   "",    "",    "",   "",   "",    "",   "",    "",   "",    "",   ""}
    };

    date    = new Date(lTime);
    nValues = new int[6];

    nValues[0] = date.getDate();
    nValues[1] = date.getMonth()+ 1;
    nValues[2] = date.getYear() + 1900;
    nValues[3] = date.getHours();
    nValues[4] = date.getMinutes();
    nValues[5] = date.getSeconds();

    for(int i=0; i<6; i++)
    {
      str = String.valueOf(nValues[i]);
      strMap[1][2*i] = str;

      if(i==2) // year [Y] only last 2 digits used
      {
        str = str.substring(2);
      }
      else if(str.length() == 1)
      {
        str = '0' + str;
      }

      strMap[1][2*i+1] = str;
    }

    strMap[1][12] = strMonth[0][date.getMonth()];
    strMap[1][13] = strMonth[1][date.getMonth()];

    for(int i=0; i<14; i++)
    {
      str = replaceSubstring(m_strLastModif, strMap[0][i], strMap[1][i]);

      if(bFormat == false && !str.equals(m_strLastModif))
        bFormat = true; // check until first change to original string is found

      m_strLastModif = str;
    }

    if(bFormat == false) // default formatting; no format string supplied
      m_strLastModif+= date.toLocaleString();
  }

/**
* Replace all occurences of subOld in str by subNew.
* @param___str__string to be modified
* @param___subOld__substring to be replaced by subNew
* @param___subNew__substring to replace subOld
* @return___String__modified String
*/
  private String replaceSubstring(String str, String subOld, String subNew)
  {
    String strNew;
    int nIdx; 

    while(true)
    {
      nIdx = str.indexOf(subOld);

      if(nIdx == -1)
        return str;

      strNew = str.substring(0, nIdx);
      strNew+= subNew;
      str    = strNew + str.substring(nIdx+subOld.length());
    }
  }

  public void update(Graphics g)
  {// avoid repainting of background
    g.setColor(getForeground());
    paint(g);
  }

/**
* Paint handler.
* If m_imgBkGnd is valid it is painted onto the applet background.
* @see drawBkGndImg()
* m_strLastModif is printed in black. 
* The string is indented 4 pixels from the left border and 
* vertically centered in the applet area.
*/
	public void paint(Graphics g)
	{   
    if(m_imgBkGnd != null)
      drawBkGndImg(g);

    FontMetrics m = getFontMetrics(getFont());
    g.drawString(m_strLastModif, 4, (size().height-m.getHeight())/2 + m.getAscent()+m.getLeading());

	//	if(m_strErrorMsg.length() > 0)
  //    g.drawString(m_strErrorMsg, 2, m.getHeight());
	}

/**
* If m_imgBkGnd is valid it is painted onto the applet background.
* The image is repeated as often as necessary to fill entire applet area
*/
  public void drawBkGndImg(Graphics g)
  {
    if(m_imgBkGnd == null || m_imgBkGnd.getHeight(this) == -1 || m_imgBkGnd.getWidth(this) == -1)
      return; // width or height not yet known

		Rectangle r = g.getClipRect();
    int i,j;

    for(j=0; j<r.height-m_ptOffset.x; j+=m_imgBkGnd.getHeight(null))
      for(i=0; i<r.width-m_ptOffset.y; i+=m_imgBkGnd.getWidth(null))
        g.drawImage(m_imgBkGnd, m_ptOffset.x - r.x+i, m_ptOffset.y - r.y+j, this);
  }

	//		The start() method is called when the page containing the applet
	// first appears on the screen. The AppletWizard's initial implementation
	// of this method starts execution of the applet's thread.
	//--------------------------------------------------------------------------
	public void start()
	{
    if(m_strBkGnd.length() > 0)
		{
			Color color=null;

			if(parseColor(m_strBkGnd, color) == true)
			{
        setBackground(color); 
				return; // no image file defined
			}
    // if m_strBkGnd defines a color instead of an image
    // BkGnd color is set
		}
    
		// m_strBkGnd did not define a valid color
		// try to load image instead
    if(m_imgBkGnd == null)
      loadBkGndImage();

    repaint();
	}
	
/**
* Decodes color from parameter string "BkGnd" or "FontColor"
* Color string must be in html hex format starting with #,
* followed by six hexadecimal letters e.g. #F0CAD5.
* Two letters form a single colorvalue. 
* Sequence is Red-Green-Blue.
* If any digits are missing the respective color values default to 0.
* If an error occurs, the default return value is Color.black
* @param___strColor__seven letter hex number prefixed with '#'
* @param___color__defined color
*/
  private boolean parseColor(String strColor, Color color)
  {// returns true if color-string was specified
   // false if string refers to an image or str is empty
    String str;
		boolean retval = true;
    int r=0,g=0,b=0;

    if(strColor.length() == 0 || strColor.charAt(0) != '#')
		{
      color = Color.black;
      return false;
		}

    try
    {
      str = strColor.substring(1,3);
      r   = hexToInt(str);
      str = strColor.substring(3,5);
      g   = hexToInt(str);
      str = strColor.substring(5,7);
      b   = hexToInt(str);
    }
    catch(StringIndexOutOfBoundsException e)
    {
      m_strErrorMsg+= "Invalid color string: " + strColor + "\n\r";
      retval = false;
    }

    color = new Color(r,g,b);
		return retval;
  }

/**
* Decodes fontname; type; size; color from parameter string "Font"
* Color substring must be in html hex format.
* Font is set as current applet font
* Color is set as foreground color
* @param___str__delimited string (;,|)
* @see parseColor
*/
  public void parseFontParam(String str)
  {
    StringTokenizer st;
    String strName, strType, strColor, strSize;
    int    nSize, nType;

    strName  = null;
    nType    = Font.PLAIN;
    strColor = "#000000";
    nSize    = 10;

    st = new StringTokenizer(str, ";,|\n\r\t");

    try
    {
      strName = st.nextToken().trim();

      nSize   = Integer.parseInt(st.nextToken().trim());

      strType = st.nextToken().trim().toUpperCase();
      nType   = (strType.equals("ITALIC")? Font.ITALIC :
                 strType.equals("BOLD")?   Font.BOLD   : Font.PLAIN);

      strColor= st.nextToken().trim();
    }
    catch(NumberFormatException e)
    {// thrown by parse int
    }
    catch(NoSuchElementException e)
    {// thrown by tokenizer
    }

    if(strName == null || strName.length() == 0)
      strName = getFont().getName();

    setFont(new Font(strName, nType, nSize));

    if(strColor.length() > 0)
		{
			Color color=null;			
			if(parseColor(strColor, color) == true)
        setForeground(color);
		}
  } 

/**
* Converts hexadecimal string to an integer.
* @param___strHexNumber__two letter hex number
* @return___int__converted string
*/
  private int hexToInt(String strHexNumber)
  {
    String str;
    String strHex = "0123456789ABCDEF";
    int i, val, n;

    val = 0;
    n   = 1;
    str = strHexNumber.toUpperCase();

    for(i=str.length()-1; i>=0; i--, n*=16)
    {
      val+= n * strHex.indexOf(str.charAt(i)); 
    }

    return val;
  }


/**
* Loads background image from parameter string "BkGnd"
* Initializes member variable m_imgBkGnd.
* If an error occurs while loading status line shows:
* "bkgnd-img load error" and m_imgBkGnd is set to null.
*/
  private void loadBkGndImage()
  {
    if(m_strBkGnd.length() == 0)
      return;

    MediaTracker tracker = new MediaTracker(this);

    m_imgBkGnd = getImage(getDocumentBase(), m_strBkGnd);
    tracker.addImage(m_imgBkGnd, 0);

    // Wait until all images are fully loaded
    //------------------------------------------------------------------
		try
		{
			tracker.waitForAll();

			if(tracker.isErrorAny() == true)
      {
        m_strErrorMsg+= "BkGnd image not loaded: " + getDocumentBase() + "; " + m_strBkGnd + "\n\r";
        showStatus("bkgnd-img load error");
        m_imgBkGnd = null;
      }
		}
		catch (InterruptedException e)
		{
			// TODO: Place exception-handling code here in case an
			//       InterruptedException is thrown by Thread.sleep(),
			//		 meaning that another thread has interrupted this one
		}
  }

  //		The stop() method is called when the page containing the applet is
	// no longer on the screen. The AppletWizard's initial implementation of
	// this method stops execution of the applet's thread.
	//--------------------------------------------------------------------------
	public void stop()
	{
	}
}
