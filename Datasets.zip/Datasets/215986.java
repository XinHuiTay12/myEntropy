/*

 * PointButton used to have a "pointing" button

 * by Ben Soares <bs@st-and.ac.uk>

 */



import java.awt.*;



public class PointButton extends Canvas {



	String direction;

	boolean texton = false;

	String text;

	int size;

	boolean fill = false;

	Color textcolour = Color.red;

	Dimension preferredSize;

	

    public PointButton(String direction) {

		this.direction = direction;

		this.size = 20;

		if (direction.equals("North") || direction.equals("South"))  {

			preferredSize = new Dimension(size*2+1, size+1);

		} else if (direction.equals("Square")) {

			preferredSize = new Dimension(size*2+1, size*2+1);

		} else {

			preferredSize = new Dimension(size+1, size*2+1);

		}

    }

    

    public PointButton(String direction, int size) {

		this.direction = direction;

		this.size = size;

		if (direction.equals("North") || direction.equals("South"))  {

			preferredSize = new Dimension(size*2+1, size+1);

		} else if (direction.equals("Square")) {

			preferredSize = new Dimension(size*2+1, size*2+1);

		} else {

			preferredSize = new Dimension(size+1, size*2+1);

		}

    }

    

    public PointButton(String direction, int size, String text) {

		this.direction = direction;

		this.size = size;

		this.text = text;

		this.texton = true;

		if (direction.equals("North") || direction.equals("South"))  {

			preferredSize = new Dimension(size*2+1, size+1);

		} else if (direction.equals("Square")) {

			preferredSize = new Dimension(size*2+1, size*2+1);

		} else {

			preferredSize = new Dimension(size+1, size*2+1);

		}

    }

    

    public PointButton(String direction, int size, String text, Color textcolour) {

		this.direction = direction;

		this.size = size;

		this.text = text;

		this.texton = true;

		this.textcolour = textcolour;

		if (direction.equals("North") || direction.equals("South"))  {

			preferredSize = new Dimension(size*2+1, size+1);

		} else if (direction.equals("Square")) {

			preferredSize = new Dimension(size*2+1, size*2+1);

		} else {

			preferredSize = new Dimension(size+1, size*2+1);

		}

    }

	

    public String getDirection() {

		return direction;

    }



    public void setDirection(String direction) {

		this.direction = direction;

    }



	public void setSize(int size)  {

		this.size = size;

		if (direction.equals("North") || direction.equals("South"))  {

			preferredSize = new Dimension(size*2+1, size+1);

		} else if (direction.equals("Square")) {

			preferredSize = new Dimension(size*2+1, size*2+1);

		} else {

			preferredSize = new Dimension(size+1, size*2+1);

		}

	}

	

	public void setText(String text)  {

		this.texton = true;

		this.text = text;

	}

	

	public void setTextColour(Color textcolour)  {

		this.textcolour = textcolour;

	}

	

	public boolean mouseDown(int mx, int my)  {

		fill = true;

		repaint();

		return true;

	}

	

	public boolean mouseUp(int mx, int my)  {

		fill = false;

		repaint();

		return true;

	}

	

	public boolean mouseDrag(int mx, int my)  {

		if (inside(mx, my)) {

			fill = true;

		} else {

			fill = false;

		}

		repaint();

		return false;

	}



	public Dimension minimumSize() {

		return preferredSize;

	}



	public Dimension preferredSize() {

		return preferredSize;

	}

	

	// The addnotify is apparently very important! although I don't think it does anything

	public void addNotify()  {

		super.addNotify();

	}

	

	public void flash()  {

		fill = true;

		repaint();

		fill = false;

		repaint();

	}



	public void check(int mx, int my) {

	}

	

	public void paint(Graphics g)  {

		Polygon arrow = new Polygon();

		size--;

		if (direction.equals("North"))  {

			arrow.addPoint(0, size);

			arrow.addPoint(size*2, size);

			arrow.addPoint(size, 0);

			arrow.addPoint(0, size);

		} else if (direction.equals("South")) {

			arrow.addPoint(0, 0);

			arrow.addPoint(size*2, 0);

			arrow.addPoint(size, size);

			arrow.addPoint(0, 0);

		} else if (direction.equals("East")) {

			arrow.addPoint(0, 0);

			arrow.addPoint(0, size*2);

			arrow.addPoint(size, size);

			arrow.addPoint(0, 0);

		} else if (direction.equals("West")) {

			arrow.addPoint(size, 0);

			arrow.addPoint(size, size*2);

			arrow.addPoint(0, size);

			arrow.addPoint(size, 0);

		} else if (direction.equals("Square")) {

			arrow.addPoint(0, 0);

			arrow.addPoint(size*2, 0);

			arrow.addPoint(size*2, size*2);

			arrow.addPoint(0, size*2);

			arrow.addPoint(0, 0);

		}

		if (fill)  {

			g.setColor(Color.black);

		} else {

			g.setColor(Color.white);

		}

		g.fillPolygon(arrow);

		g.setColor(Color.black);

		g.drawPolygon(arrow);

		int width;

		int height;

		if (direction.equals("North") || direction.equals("South"))  {

			width = size*2;

			height = size;

		} else if (direction.equals("Square")) {

			width = size*2;

			height = size*2;

			g.setColor(Color.darkGray);

			g.drawLine(0, size, size*2, size);

			g.drawLine(size, 0, size, size*2);

		} else {

			width = size;

			height = size*2;

		}

		if (texton) {

			g.setColor(textcolour);

			g.drawString(text, (int)((width - g.getFontMetrics().stringWidth(text))/2), (int)((width - g.getFontMetrics().getHeight())/2) + g.getFontMetrics().getHeight());

		}

		size++;

		

	}

	

	



    protected String paramString() {

		return super.paramString() + ",direction=" + direction + ",size=" + size + ",text=" + text;

    }

}





