-- M:\Phoenix\DB Scripts\FB_HJ3.sql
--
-- Generated for Oracle 8.1 on Wed Dec 22  10:33:07 2004 by Server Generator 6.5.52.1.0


SPOOL FB_HJ3.lst

@@FB_HJ3.tab
@@FB_HJ3.ind
@@FB_HJ3.con
@@FB_HJ3.sqs
@@FB_HJ3.trg
@@FB_HJ3.avt

SPOOL OFF
