-- \\D0server4\users\gallas\database\cdsddl_rr.sql
--
-- Generated for Oracle 8 on Wed Nov 22  10:14:48 2000 by Server Generator 6.0.3.3.0


SPOOL cdsddl_rr.lst

@@ cdsddl_rr.tab
@@ cdsddl_rr.con
@@ cdsddl_rr.sqs
@@ cdsddl_rr.trg
@@ cdsddl_rr.syn
@@ cdsddl_rr.grt

SPOOL OFF
