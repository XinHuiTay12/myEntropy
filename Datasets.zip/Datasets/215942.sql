-- C:\Documents and Settings\spw\Desktop\trigger ddls\cdsddl.sql
--
-- Generated for Oracle 9i on Wed Jul 19  10:58:24 2006 by Server Generator 9.0.2.92.10


SPOOL cdsddl.lst

@@cdsddl.tab
@@cdsddl.vw
@@cdsddl.ind
@@cdsddl.con
@@cdsddl.syn
@@cdsddl.trg
@@cdsddl.grt

SPOOL OFF
