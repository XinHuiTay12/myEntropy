-- M:\Phoenix\DB Scripts\fb_reg_forms.sql
--
-- Generated for Oracle 8.1 on Wed Dec 01  12:05:19 2004 by Server Generator 6.5.52.1.0


set echo off
set scan off


@@fb_reg_forms.tab
@@fb_reg_forms.ind
@@fb_reg_forms.con
@@fb_reg_forms.sqs
@@fb_reg_forms.trg

set echo on
set scan on

